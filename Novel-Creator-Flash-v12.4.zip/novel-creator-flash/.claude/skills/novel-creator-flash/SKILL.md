---
name: novel-creator-flash
description: 快速批量生产小说的并行创作 Skill。每个 Writer 拥有连续五章，但按 2+2+1 小步直接写本地 raw，多 Writer 并行；主Agent按正文实际结果收敛，不让 report/状态手续抵消并行收益。
when_to_use: 用户要求快速批量生成、续写或扩写小说，尤其需要多个写手并发生产大量章节并由主Agent统一整合时使用。
argument-hint: "新建 / 快速批量写作 / 继续生产 / 修订 / 导出"
user-invocable: true
disable-model-invocation: false
allowed-tools:
  - Read
  - Glob
  - Grep
  - Agent
  - 'Edit(/.novel/**)'
  - 'Edit(/project.md)'
  - 'Edit(/canon/**)'
  - 'Edit(/plot/**)'
  - 'Edit(/state/**)'
  - 'Edit(/drafts/**)'
  - 'Edit(/chapters/**)'
  - 'Edit(/revisions/**)'
  - 'Edit(/audits/**)'
  - 'Edit(/exports/**)'
  - 'Bash("${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" *)'
---
# Novel Creator Flash

运行要求：Python 3.10+；Claude Code 2.1.228+。真实 Agent / permission 行为应以 Claude Code runtime smoke 验证。

用户请求：`$ARGUMENTS`

## 第一原则：并行必须真的更快

Flash 的目的不是“让更多 Agent 同时维护更多 JSON”，而是尽快产生可用正文。**正文是主数据；Writer report、Block Interface、Working State、rebase 和 integration metrics 都是辅助。辅助数据坏了可以重建，不能扣住已经写好的五章正文。**

不要为普通小说生产建立 TaskCreate/Todo 式章节项目。主Agent只做必要的调度、收敛和审读。

## Writer：五章 ownership，2+2+1 输出

每个 Writer 仍负责连续 5 章，保持自己的局部人物余温、临时细节和对白回声；但**单次 Agent 调用最多新写两章**，避免一次要求 1.8—2.3 万字导致中断或后半块普遍缩水。

`prepare-production` 的 assignment 会给出 `write_phases`：通常为 `2章 + 2章 + 1章`。**每个 phase 都启动一个新的 subagent invocation，但仍指定同一个 `novel-fast-writer-N` 席位。不要用 `SendMessage` / resume 恢复上一 phase 的 agent 实例。** 新 invocation 直接读取本席已经落盘的 raw 和必要 writer context，从实际结尾承接；这样五章 ownership 不变，但每段获得新的上下文预算。

Writer 拥有真实：

```text
Read / Glob / Grep / Write / Edit
```

可以直接创建和修改任务卡指定的本地 raw Markdown 与 report JSON。优先读 writer context；若 context 缺少真正影响当前场景的事实、人物声音或设定，可以补读相关 `project.md / canon / plot / 已提交正文`。写权限只用于本席 raw、phase completion marker 和 report，不写正史、状态和其它 Writer 文件。

## 默认字数口径

若用户没有另行指定，本 Skill 的“字数/字符数”统一按**正文非空白字符数**计算：章节标题不计；正文中的汉字、数字、英文、标点、括号、系统提示都计；空格、换行、Tab 不计。

**字数永远以当前用户明确要求为准。** Skill 内置篇幅 fallback 只在用户完全没有给任何篇幅要求时生效；用户一旦给出区间、下限、上限或目标，主Agent必须在 `prepare-production` / Writer 调用前用 `configure` 同步，并且 Writer 任务只携带用户这套数字，不能再把 fallback 数字混进任务。

例如 `3500—4500`：同步为 hard minimum=3500、target≈4000、user maximum=4500；Writer 第一次完整写本章就瞄准约 `4000`。每个 phase 完成后主Agent统计一次；进入区间立即停止围绕字数修改。真正越界时只允许一次结构性增/删，不再一章一章“差8字再补、删后又补”。

没有用户明确下限时，内置 fallback 只是软提示，不是 hard gate；短促过场、梦境、短信体、插叙或高潮短章可以自然成立。用户明确上限超出时只输出一次 `length_warning`，不把上限改成 hard gate。

## 正常 Flash 路径

```text
主Agent读取最小必要方向
→ prepare-production 只开当前 Wavefront
→ 每个 Writer 席位按 write_phases 直接写本地 raw：2 + 2 + 1；每段新 invocation，不 resume 上一实例
→ 每个 phase 的 raw 完整后，Writer 最后写 completion_marker；partial/blocked 时不写
→ production-status：正文文件有效 + 三个 phase completion marker 完整 + 用户明确 hard minimum（若有），即 prose_ready
→ report 缺失/格式错只标 metadata_ready=false，不阻塞已确认完成的正文
→ promote-production --start N：按正史顺序把 validated raw 原样进入 staging；主Agent只 Edit 真正需要修的 hotspot
→ 后续 speculative 块有真实入口漂移时才做 rebase；没 report 直接以实际正文为准
→ adopt-interface：只在需要交接摘要时吸收有用信息；report 坏了也能从 staging 建最小 provisional state
→ 冻结正式五章 blind packet，后台做 Flow Reader + 固定一次 Pure Reader；若用户还要求继续写，可继续当前安全 Wavefront，不必等 finalize/commit 才产生后续正文
→ 主Agent先修高价值问题；Writer continuity risk 只是 advisory
→ 修订后若仍有具体事实风险，再按需调用 Continuity
→ final-clean 只硬拦确定性残渣
→ finalize-review：若本单元修订改变了冻结正文且后续 staging 已存在，只返回 downstream warning 提醒检查接口，不建立依赖账本、不阻塞继续写
→ commit-unit
```

Writer 池最多 10 席，但默认 Wavefront 仍只领先约 2 个五章块。`writer_pool_size` 是容量，不代表应一次把几十章全部猜完。用户明确极限速度时才使用深度推测。

## 轻量 Writer report

常规生产使用 **schema 3**，只记录交接价值高的内容：

```text
chapter_notes: 每章一句变化摘要 + 真正连续性风险
block_interface:
  assumed_entry
  exit_state
  must_carry_forward
  hard_inventions
  plan_deviations
  creative_keep
  continuity_risks
```

不要求 Writer 维护 Reader Model action、实体 ID、commit current_patch 或 adjudication 对象。schema 1/2 数据仍可读取。

`production-status` 明确区分：

- `prose_ready`：五篇 raw 存在、章号正确、达到用户明确硬篇幅（若有），且三个 phase completion marker 都确认完成；
- `metadata_ready`：report 也结构正确；
- `ready` = `prose_ready`。

completion marker 只证明 Writer 明确完成该 phase，不承担文学长度判断；因此有意短章可以完成，而半截 raw 不会仅因文件存在就被推进。report JSON 写坏不会扣住已经通过完成信号确认的正文。`state/events/events.jsonl` 损坏时，普通 Writer/author context 只 warning 并跳过事件索引；outline node、current arc、scene/active entity 或实体 JSON 失配也只省略辅助块。无 events / 无事件依赖的章节仍可 commit 且保留坏日志原样；真正事件依赖章才阻止。`audit` 继续严格报告。

`prepare-review` 自动判断来源时以实际 prose evidence 为准：当前五章存在 matching 且 `prose_ready` 的 Writer assignment 才自动视为 `production`；否则完整 staging 直接视为主Agent正文。旧 production manifest、provisional 或失败 assignment 不能反过来扣住已经写好的 staging。

## Reader / Reviewer 权限

- Flow / Hook / Character / Pure Reader：真实 `Read`。任务只指定一个 blind packet；没有 Write/Edit。
- Continuity Reviewer：真实 `Read/Glob/Grep`，可查正文、canon、state、plot 和 production，但不修改文件。
- 不再把 `Read(/path/**)` 写进 subagent 的 `tools:`，避免运行环境把它解析成不存在的工具。

Pure Reader **每个正式创作单元固定调用一次**，没有编辑职责，只说自然阅读反应。

Writer report 里的 `continuity_risks` 只是提醒，不自动升级 Reviewer。先完成盲读和高价值修订；只有最终候选仍存在具体事实/知识边界/时间线风险时，才用 `review-continuity --invoke --reason ...` 调 Continuity Reviewer。
正式 review 的 blind packet 只含中性范围信息与冻结正文，不携带任意 `reader_brief`。`reader_brief` 若有，只能作为 First/Flow/Hook/Character 等专业 Reader 的任务补充；调用 Pure Reader 时只给 blind packet 路径，不附专业审稿方向。


## 创作与收敛

计划不是正文脚本。人物特点要偶尔制造不最优选择；能力和幸运只增加机会，不保证答案。配角有自己的利益。主Agent整合时只修接口、事实漂移、明显重复、低级残渣和少量高价值文气问题，不把 Writer 的五章全部重写成统一腔。

跨块以实际前块终稿为准。`rebase-production` 只修真实失配，不因为 report 的软建议全面返工。schema3 的 carry-forward/hard fact 是交接便笺，不要求逐条办 accepted/rejected/deferred 手续。

## 工具与运行

`novelctl-skill` 在项目环境变量缺失时允许从当前目录/现有 `.novel` 工作区恢复，不再为了项目根绑定停工；Windows 输出尽量使用 UTF-8。章节标题解析同时接受 `# 第N章 标题` 和 `第N章 标题`。

常用命令：`init`、`configure`、`context`、`prepare-production`、`production-status`、`promote-production`、`rebase-production`、`adopt-interface`、`chapter-stats`、`prepare-review`、`review-continuity`、`final-clean`、`finalize-review`、`commit-unit`、`audit`、`export`。

`adjudicate-interface` 只用于 schema2 数据；常规生产不需要它。`working-state / prepare-delta / commit / integration-metrics` 仍可用于恢复与精细维护，但普通生产不应因为这些辅助步骤停住。

细节见 `references/operations.md`。
