#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,subprocess,sys
from pathlib import Path
from batch_state import load_active_review_unit
from common import load_json,validate_workspace_layout

def run(script:Path,*args:str)->subprocess.CompletedProcess[str]:
    return subprocess.run([sys.executable,str(script),*args],text=True,capture_output=True)

def main()->int:
    p=argparse.ArgumentParser(description="Commit the current finalized review unit sequentially. Convenience wrapper; prose remains the source of truth.")
    p.add_argument("workspace",nargs="?",default=".")
    a=p.parse_args(); root=Path(a.workspace).resolve(strict=True)
    try:
        validate_workspace_layout(root); current=load_json(root/"state/current.json",required=True)
        if not isinstance(current,dict): raise ValueError("state/current.json must be an object")
        unit=load_active_review_unit(root,current); start,end=unit["start_chapter"],unit["end_chapter"]
        scripts=Path(__file__).resolve().parent; committed=[]; warnings=[]
        for chapter in range(start,end+1):
            current=load_json(root/"state/current.json",required=True); latest=current.get("latest_chapter",0) if isinstance(current,dict) else 0
            if isinstance(latest,int) and latest>=chapter:
                continue
            prep=run(scripts/"prepare_delta.py",str(root),"--chapter",str(chapter))
            if prep.returncode!=0 and "delta already contains work" not in prep.stderr:
                raise ValueError(f"prepare-delta chapter {chapter} failed: {prep.stderr.strip() or prep.stdout.strip()}")
            commit=run(scripts/"commit_chapter.py",str(root),"--chapter",str(chapter))
            if commit.returncode!=0:
                raise ValueError(f"commit chapter {chapter} failed: {commit.stderr.strip() or commit.stdout.strip()}")
            try:
                commit_payload=json.loads(commit.stdout)
                for item in commit_payload.get("warnings",[]) if isinstance(commit_payload,dict) else []:
                    if isinstance(item,str) and item.strip(): warnings.append(f"chapter {chapter}: {item.strip()}")
            except json.JSONDecodeError:
                pass
            committed.append(chapter)
    except ValueError as exc:
        p.error(str(exc))
    print(json.dumps({"committed":committed,"range":f"{start}-{end}","warnings":warnings,"note":"Review-unit commit completed. Auxiliary warnings do not invalidate committed prose; audit/export remain optional follow-up operations."},ensure_ascii=False)); return 0
if __name__=="__main__": raise SystemExit(main())
