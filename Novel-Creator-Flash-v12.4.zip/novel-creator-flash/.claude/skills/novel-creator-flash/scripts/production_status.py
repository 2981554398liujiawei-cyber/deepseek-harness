#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from chapter_stats import analyze_chapter_text,load_length_settings
from common import load_json,read_text,safe_workspace_path,sha256_text,title_chapter_number,validate_workspace_layout
from production_state import production_manifest_relative_from_current,validate_manifest

REPORT_LIST_FIELDS=("newly_invented_details","character_micro_changes","new_promises","motifs_or_objects","strong_lines_or_moments","possible_continuity_risks")

def validate_report(data:object,assignment:dict)->list[str]:
    errors=[]
    if not isinstance(data,dict) or data.get("schema") not in (1,2,3): return ["report must be schema 1, 2, or 3"]
    for key in ("writer","start_chapter","end_chapter"):
        if data.get(key)!=assignment.get(key): errors.append(f"report {key} does not match assignment")
    if data.get("schema")==1:
        for key in REPORT_LIST_FIELDS:
            value=data.get(key)
            if not isinstance(value,list) or any(not isinstance(x,str) for x in value): errors.append(f"report {key} must be a list of strings")
        return errors
    if data.get("schema")==3:
        notes=data.get("chapter_notes",[])
        if not isinstance(notes,list): errors.append("schema 3 report chapter_notes must be a list")
        else:
            seen=[]
            for i,row in enumerate(notes):
                if not isinstance(row,dict): errors.append(f"chapter_notes[{i}] must be an object"); continue
                chapter=row.get("chapter"); seen.append(chapter)
                if not isinstance(chapter,int) or isinstance(chapter,bool): errors.append(f"chapter_notes[{i}].chapter must be an integer")
                if not isinstance(row.get("summary",""),str): errors.append(f"chapter_notes[{i}].summary must be a string")
                risks=row.get("continuity_risks",[])
                if not isinstance(risks,list) or any(not isinstance(x,str) for x in risks): errors.append(f"chapter_notes[{i}].continuity_risks must be a list of strings")
            expected=set(range(assignment["start_chapter"],assignment["end_chapter"]+1))
            if any(isinstance(x,int) and x not in expected for x in seen): errors.append("chapter_notes contains chapter outside assignment")
        interface=data.get("block_interface",{})
        if not isinstance(interface,dict): errors.append("schema 3 block_interface must be an object")
        else:
            for key in ("assumed_entry","exit_state"):
                if key in interface and not isinstance(interface.get(key),dict): errors.append(f"block_interface.{key} must be an object")
            for key in ("must_carry_forward","hard_inventions","plan_deviations","creative_keep","continuity_risks"):
                value=interface.get(key,[])
                if not isinstance(value,list) or any(not isinstance(x,str) for x in value): errors.append(f"block_interface.{key} must be a list of strings")
        return errors
    # Schema 2 reports remain readable for existing projects.
    deltas=data.get("chapter_deltas")
    expected=list(range(assignment["start_chapter"],assignment["end_chapter"]+1))
    if not isinstance(deltas,list) or len(deltas)!=5: errors.append("schema 2 report chapter_deltas must contain exactly five entries")
    else:
        got=[]
        for i,row in enumerate(deltas):
            if not isinstance(row,dict): errors.append(f"chapter_deltas[{i}] must be an object"); continue
            got.append(row.get("chapter"))
            if not isinstance(row.get("summary",""),str): errors.append(f"chapter_deltas[{i}].summary must be a string")
            if not isinstance(row.get("current_patch",{}),dict): errors.append(f"chapter_deltas[{i}].current_patch must be an object")
            if not isinstance(row.get("reader_model_updates",[]),list): errors.append(f"chapter_deltas[{i}].reader_model_updates must be a list")
        if got!=expected: errors.append("chapter_deltas chapter sequence must exactly match assigned five chapters")
    interface=data.get("block_interface")
    if not isinstance(interface,dict): errors.append("schema 2 report block_interface must be an object")
    return errors

def report_risks(data:object)->list[str]:
    if not isinstance(data,dict): return []
    if data.get("schema")==3:
        out=[]
        for row in data.get("chapter_notes",[]) if isinstance(data.get("chapter_notes",[]),list) else []:
            if isinstance(row,dict):
                for x in row.get("continuity_risks",[]) if isinstance(row.get("continuity_risks",[]),list) else []:
                    if isinstance(x,str) and x.strip(): out.append(x.strip())
        interface=data.get("block_interface",{})
        if isinstance(interface,dict):
            for x in interface.get("continuity_risks",[]) if isinstance(interface.get("continuity_risks",[]),list) else []:
                if isinstance(x,str) and x.strip(): out.append(x.strip())
        return list(dict.fromkeys(out))
    if data.get("schema")==2 and isinstance(data.get("block_interface"),dict):
        value=data["block_interface"].get("possible_continuity_risks",[]); return value if isinstance(value,list) else []
    value=data.get("possible_continuity_risks",[]); return value if isinstance(value,list) else []

def _canonical_phases(assignment:dict)->list[dict]:
    start=int(assignment["start_chapter"]); end=int(assignment["end_chapter"])
    outputs=assignment.get("outputs",[])
    raw_dir=Path(outputs[0]).parent.as_posix() if isinstance(outputs,list) and outputs else ""
    expected=[
        {"start_chapter":start,"end_chapter":start+1,"completion_marker":f"{raw_dir}/phase-{start:04d}-{start+1:04d}.complete"},
        {"start_chapter":start+2,"end_chapter":start+3,"completion_marker":f"{raw_dir}/phase-{start+2:04d}-{start+3:04d}.complete"},
        {"start_chapter":start+4,"end_chapter":end,"completion_marker":f"{raw_dir}/phase-{start+4:04d}-{end:04d}.complete"},
    ]
    actual=assignment.get("write_phases")
    if isinstance(actual,list) and len(actual)==len(expected):
        merged=[]
        for got,want in zip(actual,expected):
            row=dict(want)
            if isinstance(got,dict):
                row["start_chapter"]=got.get("start_chapter",want["start_chapter"])
                row["end_chapter"]=got.get("end_chapter",want["end_chapter"])
                row["completion_marker"]=got.get("completion_marker") or want["completion_marker"]
            merged.append(row)
        return merged
    return expected


def evaluate_assignment(root:Path,assignment:dict,settings:dict)->dict:
    chapter_results=[]; chapter_prose_valid=True
    outputs=assignment.get("outputs"); expected_chapters=list(range(assignment["start_chapter"],assignment["end_chapter"]+1))
    if not isinstance(outputs,list) or len(outputs)!=len(expected_chapters):
        return {"writer":assignment.get("writer"),"range":f"{assignment.get('start_chapter')}-{assignment.get('end_chapter')}","ready":False,"prose_ready":False,"completion_ready":False,"metadata_ready":False,"chapters":[],"phases":[],"report":assignment.get("report"),"report_errors":["assignment outputs must contain exactly five paths"],"continuity_risks":[]}
    for chapter,output in zip(expected_chapters,outputs):
        path=safe_workspace_path(root,output,allow_missing=True); item={"chapter":chapter,"output":output,"exists":path.is_file()}
        if not path.is_file(): item["status"]="missing"; chapter_prose_valid=False
        else:
            if getattr(path.stat(),"st_nlink",1)!=1: raise ValueError(f"hard-linked writer output is not allowed: {output}")
            text=read_text(path,required=True); heading=title_chapter_number(text); item["heading_chapter"]=heading
            if heading!=chapter: item["status"]="wrong_chapter_heading"; chapter_prose_valid=False
            stats=analyze_chapter_text(text,settings); item.update(stats); item["sha256"]=sha256_text(text.rstrip()+"\n")
            if not stats["passes_minimum"]: chapter_prose_valid=False
        chapter_results.append(item)
    phase_results=[]; completion_ready=True
    for phase in _canonical_phases(assignment):
        marker_rel=phase["completion_marker"]
        marker=safe_workspace_path(root,marker_rel,allow_missing=True)
        marker_exists=marker.is_file(); marker_valid=False
        if marker_exists:
            if getattr(marker.stat(),"st_nlink",1)!=1: raise ValueError(f"hard-linked completion marker is not allowed: {marker_rel}")
            marker_valid=read_text(marker,required=True).strip()=="complete"
        if not marker_valid: completion_ready=False
        phase_results.append({"start_chapter":phase["start_chapter"],"end_chapter":phase["end_chapter"],"completion_marker":marker_rel,"marker_exists":marker_exists,"completed":marker_valid})
    prose_ready=chapter_prose_valid and completion_ready
    report_rel=assignment.get("report"); report_path=safe_workspace_path(root,report_rel,allow_missing=True) if isinstance(report_rel,str) else None; report_errors=[]; report_data=None
    if report_path is None or not report_path.is_file(): report_errors=["report missing"]
    else:
        if getattr(report_path.stat(),"st_nlink",1)!=1: raise ValueError(f"hard-linked writer report is not allowed: {report_rel}")
        try: report_data=load_json(report_path,required=True); report_errors=validate_report(report_data,assignment)
        except json.JSONDecodeError as exc: report_errors=[f"report JSON invalid: {exc}"]
    metadata_ready=not report_errors
    return {"writer":assignment.get("writer"),"range":f"{assignment['start_chapter']}-{assignment['end_chapter']}","ready":prose_ready,"prose_ready":prose_ready,"completion_ready":completion_ready,"chapter_prose_valid":chapter_prose_valid,"metadata_ready":metadata_ready,"chapters":chapter_results,"phases":phase_results,"report":report_rel,"report_schema":report_data.get("schema") if isinstance(report_data,dict) else None,"report_errors":report_errors,"continuity_risks":report_risks(report_data)}

def main()->int:
    parser=argparse.ArgumentParser(description="Check each five-chapter production block. Writer completion is confirmed by phase markers; report metadata remains advisory.")
    parser.add_argument("workspace",nargs="?",default="."); args=parser.parse_args(); root=Path(args.workspace).resolve(strict=True)
    try:
        validate_workspace_layout(root); current=load_json(root/"state/current.json",required=True)
        if not isinstance(current,dict): raise ValueError("state/current.json must be an object")
        manifest_rel=production_manifest_relative_from_current(current); manifest_path=safe_workspace_path(root,manifest_rel,allow_missing=False); manifest=load_json(manifest_path,required=True)
        errors=validate_manifest(manifest)
        if errors: raise ValueError("; ".join(errors))
        settings=load_length_settings(root); blocks=[]; all_risks=[]
        for assignment in manifest["assignments"]:
            block=evaluate_assignment(root,assignment,settings); blocks.append(block)
            for risk in block["continuity_risks"]:
                if isinstance(risk,str) and risk.strip(): all_risks.append(f"{block['range']}: {risk.strip()}")
        all_ready=all(block["prose_ready"] for block in blocks); ready_blocks=[block["range"] for block in blocks if block["prose_ready"]]
        first_unready=next((block["range"] for block in blocks if not block["prose_ready"]),None)
    except (ValueError,json.JSONDecodeError) as exc: parser.error(str(exc))
    run=current.get("production_run", {}) if isinstance(current,dict) else {}; remainder=run.get("main_agent_remainder") if isinstance(run,dict) else None
    print(json.dumps({"production_run":f"{manifest['start_chapter']}-{manifest['end_chapter']}","all_ready":all_ready,"ready_blocks":ready_blocks,"first_unready_block":first_unready,"blocks":blocks,"continuity_risk_detected":bool(all_risks),"continuity_risks":all_risks,"main_agent_remainder":remainder,"next":"按正史顺序对 prose_ready 的五章块运行 promote-production --start N。若 raw 已有正文但 completion_ready=false，让对应 Writer phase 新实例先读实际 raw，确认该 phase 完整后再写 completion_marker；不要用字数代替完成信号。metadata_ready=false 只表示 report 便笺不完整。"},ensure_ascii=False)); return 0
if __name__=="__main__": raise SystemExit(main())
