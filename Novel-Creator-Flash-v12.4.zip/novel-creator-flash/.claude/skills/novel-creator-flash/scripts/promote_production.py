#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from chapter_stats import load_length_settings
from common import atomic_write_text, load_json, read_text, safe_workspace_path, sha256_text, validate_workspace_layout
from production_state import block_for_range, production_manifest_relative_from_current, validate_manifest
from production_status import evaluate_assignment


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Promote one prose-ready five-chapter Writer block from production raw into canonical staging without rewriting it."
    )
    parser.add_argument("workspace", nargs="?", default=".")
    parser.add_argument("--start", type=int, required=True, help="First chapter of the five-chapter Writer block")
    parser.add_argument("--force", action="store_true", help="Overwrite conflicting staging only after the 主Agent explicitly chooses to replace it")
    args = parser.parse_args()
    root = Path(args.workspace).resolve(strict=True)

    try:
        validate_workspace_layout(root)
        if args.start < 1:
            raise ValueError("--start must be positive")
        current = load_json(root / "state/current.json", required=True)
        if not isinstance(current, dict):
            raise ValueError("state/current.json must be an object")
        manifest_rel = production_manifest_relative_from_current(current)
        manifest_path = safe_workspace_path(root, manifest_rel, allow_missing=False)
        manifest = load_json(manifest_path, required=True)
        errors = validate_manifest(manifest)
        if errors:
            raise ValueError("invalid production manifest: " + "; ".join(errors))
        assignment = block_for_range(manifest, args.start, args.start + 4)
        if not isinstance(assignment, dict):
            raise ValueError("no production block starts at requested chapter")
        status = evaluate_assignment(root, assignment, load_length_settings(root))
        if not status.get("prose_ready"):
            problems = []
            for item in status.get("chapters", []):
                if item.get("status") in {"missing", "wrong_chapter_heading"} or not item.get("passes_minimum", True):
                    problems.append(f"chapter {item.get('chapter')}: {item.get('status', 'not_ready')}")
            for phase in status.get("phases", []):
                if not phase.get("completed"):
                    problems.append(f"phase {phase.get('start_chapter')}-{phase.get('end_chapter')}: completion marker missing or invalid")
            raise ValueError("Writer block prose is not ready" + (": " + ", ".join(problems) if problems else ""))

        planned = []
        for chapter, raw_rel in zip(
            range(assignment["start_chapter"], assignment["end_chapter"] + 1),
            assignment["outputs"],
        ):
            raw = safe_workspace_path(root, raw_rel, allow_missing=False)
            text = read_text(raw, required=True)
            staging = safe_workspace_path(root, f".novel/staging/chapter-{chapter:04d}.md", allow_missing=True)
            existing = read_text(staging, required=True) if staging.is_file() else None
            if existing is not None and existing != text and not args.force:
                raise ValueError(
                    f"staging conflict at chapter {chapter}; inspect the existing staging or rerun with --force to replace it"
                )
            planned.append((chapter, staging, text, existing == text if existing is not None else False))

        promoted = []
        unchanged = []
        hashes = {}
        for chapter, staging, text, same in planned:
            hashes[str(chapter)] = sha256_text(text)
            if same:
                unchanged.append(chapter)
                continue
            atomic_write_text(staging, text)
            promoted.append(chapter)

    except (ValueError, json.JSONDecodeError, FileNotFoundError) as exc:
        parser.error(str(exc))

    print(json.dumps({
        "promoted": promoted,
        "unchanged": unchanged,
        "range": f"{assignment['start_chapter']}-{assignment['end_chapter']}",
        "writer": assignment["writer"],
        "staging_hashes": hashes,
        "metadata_ready": status.get("metadata_ready", False),
        "metadata_warnings": status.get("report_errors", []),
        "next": "正文已原样进入 staging。主Agent只 Edit 真正需要修的 hotspot；report/metadata 不完整不需要重写正文。需要有用交接摘要时再运行 adopt-interface。",
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
