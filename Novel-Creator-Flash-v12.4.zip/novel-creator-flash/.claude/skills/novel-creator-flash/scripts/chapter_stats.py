#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from common import chapter_filename, load_json, read_text, safe_workspace_path, title_chapter_number, validate_workspace_layout

COUNTING_METHOD = "non_whitespace_prose_chars"

DEFAULT_LENGTH_SETTINGS = {
    # 2700 is a writing preference, not a default literary hard gate.
    # It becomes hard only when the user explicitly configures a minimum.
    "minimum_effective_chars": 2700,
    "enforce_minimum_effective_chars": False,
    "target_effective_chars": 3200,
    "soft_maximum_effective_chars": 4200,
    # Built-in numbers are fallback only. User-provided length requirements take precedence.
    "user_length_configured": False,
    "warn_above_soft_maximum": False,
    "counting_method": COUNTING_METHOD,
}

DEFAULT_BATCH_SETTINGS = {
    "batch_size": 5,
    "planning_window": 10,
}


def _real_int(value: Any, field: str, *, minimum: int = 0) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError(f"{field} must be an integer")
    if value < minimum:
        raise ValueError(f"{field} must be at least {minimum}")
    return value


def load_length_settings(root: Path) -> dict[str, int]:
    """Load project defaults while remaining compatible with projects created earlier."""
    path = safe_workspace_path(root, "state/writing-settings.json", allow_missing=True)
    data = load_json(path, default=None)
    if data is None:
        return dict(DEFAULT_LENGTH_SETTINGS)
    if not isinstance(data, dict):
        raise ValueError("state/writing-settings.json must be an object")
    if data.get("schema") != 1 or isinstance(data.get("schema"), bool):
        raise ValueError("state/writing-settings.json schema must be integer 1")
    raw = data.get("chapter_length")
    if not isinstance(raw, dict):
        raise ValueError("state/writing-settings.json chapter_length must be an object")
    minimum_value = _real_int(
        raw.get("minimum_effective_chars"), "chapter_length.minimum_effective_chars", minimum=1
    )
    enforce_raw = raw.get("enforce_minimum_effective_chars")
    if enforce_raw is None:
        # Projects without an enforcement flag treat the built-in minimum as advisory.
        # a soft preference; a non-default stored minimum was likely user-set.
        enforce_minimum = minimum_value != 2700
    elif isinstance(enforce_raw, bool):
        enforce_minimum = enforce_raw
    else:
        raise ValueError("chapter_length.enforce_minimum_effective_chars must be boolean")
    target_value = _real_int(
        raw.get("target_effective_chars"), "chapter_length.target_effective_chars", minimum=1
    )
    maximum_value = _real_int(
        raw.get("soft_maximum_effective_chars"), "chapter_length.soft_maximum_effective_chars", minimum=1
    )
    user_configured_raw = raw.get("user_length_configured")
    if user_configured_raw is None:
        user_configured = enforce_minimum or target_value != 3200 or maximum_value != 4200
    elif isinstance(user_configured_raw, bool):
        user_configured = user_configured_raw
    else:
        raise ValueError("chapter_length.user_length_configured must be boolean")
    warn_max_raw = raw.get("warn_above_soft_maximum")
    if warn_max_raw is None:
        warn_maximum = user_configured and maximum_value != 4200
    elif isinstance(warn_max_raw, bool):
        warn_maximum = warn_max_raw
    else:
        raise ValueError("chapter_length.warn_above_soft_maximum must be boolean")
    settings = {
        "minimum_effective_chars": minimum_value,
        "enforce_minimum_effective_chars": enforce_minimum,
        "target_effective_chars": target_value,
        "soft_maximum_effective_chars": maximum_value,
        "user_length_configured": user_configured,
        "warn_above_soft_maximum": warn_maximum,
        "counting_method": COUNTING_METHOD,
    }
    if settings["target_effective_chars"] < settings["minimum_effective_chars"]:
        raise ValueError("target_effective_chars must be at least minimum_effective_chars")
    if settings["soft_maximum_effective_chars"] < settings["target_effective_chars"]:
        raise ValueError("soft_maximum_effective_chars must be at least target_effective_chars")
    return settings


def load_batch_settings(root: Path, *, allow_existing_batch_size: bool = False) -> dict[str, int]:
    """Load the fixed five-chapter review rhythm.

    ``allow_existing_batch_size`` is used only by ``configure`` so an older
    project can be normalized back to five without requiring manual JSON edits.
    All production/review/commit paths fail closed on any non-five value.
    """
    path = safe_workspace_path(root, "state/writing-settings.json", allow_missing=True)
    data = load_json(path, default=None)
    if data is None:
        return dict(DEFAULT_BATCH_SETTINGS)
    if not isinstance(data, dict):
        raise ValueError("state/writing-settings.json must be an object")
    raw = data.get("batch")
    if raw is None:
        return dict(DEFAULT_BATCH_SETTINGS)
    if not isinstance(raw, dict):
        raise ValueError("state/writing-settings.json batch must be an object")
    settings = {
        "batch_size": _real_int(raw.get("batch_size"), "batch.batch_size", minimum=1),
        "planning_window": _real_int(raw.get("planning_window"), "batch.planning_window", minimum=1),
    }
    if settings["batch_size"] != 5 and not allow_existing_batch_size:
        raise ValueError("batch.batch_size must equal the fixed review batch size 5; run configure --batch-size 5")
    if settings["planning_window"] < 5:
        raise ValueError("batch.planning_window must be at least 5")
    return settings


def resolve_length_settings(
    root: Path,
    *,
    minimum: int | None = None,
    target: int | None = None,
    soft_maximum: int | None = None,
) -> dict[str, int]:
    settings = load_length_settings(root)
    if minimum is not None:
        settings["minimum_effective_chars"] = _real_int(minimum, "--min-chars", minimum=1)
        settings["enforce_minimum_effective_chars"] = True
        settings["user_length_configured"] = True
    if target is not None:
        settings["target_effective_chars"] = _real_int(target, "--target-chars", minimum=1)
        settings["user_length_configured"] = True
        if minimum is None and not settings.get("enforce_minimum_effective_chars", False) and settings["target_effective_chars"] < settings["minimum_effective_chars"]:
            settings["minimum_effective_chars"] = settings["target_effective_chars"]
    if soft_maximum is not None:
        settings["soft_maximum_effective_chars"] = _real_int(soft_maximum, "--soft-max-chars", minimum=1)
        settings["user_length_configured"] = True
        settings["warn_above_soft_maximum"] = True
    if settings.get("enforce_minimum_effective_chars", False) and settings["target_effective_chars"] < settings["minimum_effective_chars"]:
        raise ValueError("target chars must be at least the explicit hard minimum")
    if settings["soft_maximum_effective_chars"] < settings["target_effective_chars"]:
        raise ValueError("soft maximum chars must be at least target chars")
    return settings


def prose_body(text: str) -> str:
    """Remove the first chapter title line (Markdown or plain); preserve prose beneath it."""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")
    lines = normalized.split("\n")
    first_nonempty = next((index for index, line in enumerate(lines) if line.strip()), None)
    if first_nonempty is not None:
        first = lines[first_nonempty].strip()
        if first.startswith("#") or title_chapter_number(first) is not None:
            del lines[first_nonempty]
    return "\n".join(lines).strip()


def analyze_chapter_text(text: str, settings: dict[str, int]) -> dict[str, Any]:
    body = prose_body(text)
    counted = sum(1 for char in body if not char.isspace())
    paragraphs = [part for part in body.split("\n\n") if part.strip()]
    minimum = settings["minimum_effective_chars"]
    target = settings["target_effective_chars"]
    soft_maximum = settings["soft_maximum_effective_chars"]
    enforce_minimum = bool(settings.get("enforce_minimum_effective_chars", False))
    warn_maximum = bool(settings.get("warn_above_soft_maximum", False))
    below_preferred = counted < minimum
    if enforce_minimum and below_preferred:
        status = "too_short"
    elif below_preferred:
        status = "below_preferred_minimum"
    elif counted < target:
        status = "acceptable"
    elif counted <= soft_maximum:
        status = "on_target"
    else:
        status = "above_soft_maximum"
    return {
        "counted_chars": counted,
        "non_whitespace_chars": counted,
        # Compatibility alias for integrations that use the earlier field name.
        # canonical non-whitespace prose-character metric.
        "effective_chars": counted,
        "counting_method": COUNTING_METHOD,
        "paragraphs": len(paragraphs),
        "minimum_effective_chars": minimum,
        "preferred_minimum_effective_chars": minimum,
        "minimum_enforced": enforce_minimum,
        "hard_minimum_effective_chars": minimum if enforce_minimum else None,
        "target_effective_chars": target,
        "soft_maximum_effective_chars": soft_maximum,
        "user_length_configured": bool(settings.get("user_length_configured", False)),
        "maximum_warning_enabled": warn_maximum,
        "above_user_maximum": warn_maximum and counted > soft_maximum,
        "status": status,
        "passes_minimum": (not enforce_minimum) or counted >= minimum,
        "shortfall": max(0, minimum - counted) if enforce_minimum else 0,
        "preferred_shortfall": max(0, minimum - counted),
        "distance_to_target": max(0, target - counted),
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Measure deterministic chapter length: count every non-whitespace prose character and exclude only the chapter title line and whitespace."
    )
    parser.add_argument("workspace", nargs="?", default=".")
    parser.add_argument("--chapter", type=int, required=True)
    parser.add_argument("--input", default="", help="Optional workspace-relative Markdown path")
    parser.add_argument("--min-chars", type=int)
    parser.add_argument("--target-chars", type=int)
    parser.add_argument("--soft-max-chars", type=int)
    args = parser.parse_args()

    root = Path(args.workspace).resolve(strict=True)
    validate_workspace_layout(root)
    if args.chapter < 1:
        parser.error("chapter must be positive")
    if args.input:
        try:
            source = safe_workspace_path(root, args.input, allow_missing=False)
        except ValueError as exc:
            parser.error(str(exc))
    else:
        staging = safe_workspace_path(root, f".novel/staging/{chapter_filename(args.chapter)}", allow_missing=True)
        formal = safe_workspace_path(root, f"chapters/{chapter_filename(args.chapter)}", allow_missing=True)
        source = staging if staging.is_file() else formal
    if not source.is_file():
        parser.error(f"chapter prose is missing: {source.relative_to(root)}")
    if getattr(source.stat(), "st_nlink", 1) != 1:
        parser.error(f"hard-linked chapter input is not allowed: {source.relative_to(root)}")
    try:
        settings = resolve_length_settings(
            root,
            minimum=args.min_chars,
            target=args.target_chars,
            soft_maximum=args.soft_max_chars,
        )
    except ValueError as exc:
        parser.error(str(exc))
    result = analyze_chapter_text(read_text(source, required=True), settings)
    result.update({
        "chapter": args.chapter,
        "source": source.relative_to(root).as_posix(),
        "metric": COUNTING_METHOD,
    })
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
