#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import atomic_write_json,load_json,read_text,safe_workspace_path,sha256_text,validate_workspace_layout
from production_state import block_for_range,production_manifest_relative_from_current,validate_manifest
from production_status import validate_report
from working_state import scaffold,compile_working_state,provisional_relative

def main()->int:
    p=argparse.ArgumentParser(description='Adopt useful Writer handoff notes into provisional state. can recover from prose alone when report metadata is missing or malformed.')
    p.add_argument('workspace',nargs='?',default='.'); p.add_argument('--start',type=int,required=True); p.add_argument('--force',action='store_true')
    a=p.parse_args(); root=Path(a.workspace).resolve(strict=True)
    try:
        validate_workspace_layout(root); current=load_json(root/'state/current.json',required=True)
        if not isinstance(current,dict): raise ValueError('state/current.json must be an object')
        manifest=load_json(safe_workspace_path(root,production_manifest_relative_from_current(current),allow_missing=False),required=True)
        errs=validate_manifest(manifest)
        if errs: raise ValueError('; '.join(errs))
        block=block_for_range(manifest,a.start,a.start+4)
        if not isinstance(block,dict): raise ValueError('no production block starts at requested chapter')
        report_path=safe_workspace_path(root,block['report'],allow_missing=True)
        report=None
        report_errors=['report missing']
        if report_path.is_file():
            try:
                report=load_json(report_path,required=True)
                report_errors=validate_report(report,block)
            except json.JSONDecodeError as exc:
                report_errors=[f'report JSON invalid: {exc}']
        schema=report.get('schema') if isinstance(report,dict) else None
        schema2={row.get('chapter'):row for row in report.get('chapter_deltas',[]) if isinstance(row,dict) and isinstance(row.get('chapter'),int)} if schema==2 and isinstance(report,dict) else {}
        schema3={row.get('chapter'):row for row in report.get('chapter_notes',[]) if isinstance(row,dict) and isinstance(row.get('chapter'),int)} if schema==3 and isinstance(report,dict) else {}
        adopted=[]
        for chapter in range(a.start,a.start+5):
            staging=safe_workspace_path(root,f'.novel/staging/chapter-{chapter:04d}.md',allow_missing=False)
            if not staging.is_file(): raise ValueError(f'canonical staging must exist before interface adoption: chapter {chapter}')
            target=safe_workspace_path(root,provisional_relative(chapter),allow_missing=True)
            if not target.exists(): scaffold(root,chapter,False)
            elif not a.force: raise ValueError(f'provisional delta already exists for chapter {chapter}; use --force after reviewing it')
            base=load_json(target,required=True)
            if not isinstance(base,dict): raise ValueError('provisional delta scaffold malformed')
            base['prose_source']='production'; base['prose_sha256']=sha256_text(read_text(staging,required=True).rstrip()+'\n')
            if not report_errors and schema==3:
                row=schema3.get(chapter,{})
                if isinstance(row,dict) and isinstance(row.get('summary'),str) and row.get('summary').strip(): base['summary']=row['summary'].strip()
            elif not report_errors and schema==2:
                row=schema2.get(chapter,{})
                if isinstance(row,dict):
                    if isinstance(row.get('summary'),str): base['summary']=row.get('summary','')
                    if isinstance(row.get('reader_model_updates'),list): base['reader_model_updates']=row['reader_model_updates']
                    if isinstance(row.get('current_patch'),dict): base['current_patch']=row['current_patch']
                    if isinstance(row.get('plan_deviations'),list) and row['plan_deviations']:
                        base['dominant_change']=base.get('dominant_change') or '；'.join(str(x) for x in row['plan_deviations'][:2])
            atomic_write_json(target,base); adopted.append(chapter)
        working=compile_working_state(root,write=True)
    except (ValueError,json.JSONDecodeError) as exc:p.error(str(exc))
    print(json.dumps({'adopted':adopted,'working_state':'.novel/staging/working-state.json','report_schema':schema,'metadata_warnings':report_errors,'working_state_warnings':working.get('warnings',[]) if isinstance(working,dict) else [],'note':'正文优先。schema3 report 只补摘要；report 缺失/格式坏也会从 staging 正文建立最小 provisional state，不阻塞审读。'},ensure_ascii=False)); return 0
if __name__=='__main__':raise SystemExit(main())
