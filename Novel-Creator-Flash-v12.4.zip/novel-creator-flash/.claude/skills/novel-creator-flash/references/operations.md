# Novel Creator Flash 操作参考

本参考只服务实际命令。Flash 的目标是更快地产生可用正文，不是更快地产生 metadata。

补充：普通写作 context 遇到损坏的 `state/events/events.jsonl` 时只 warning 并跳过事件索引；正式 `audit` 仍严格报告。`prepare-review` 的自动 source inference 以实际 ready Writer raw 为 production 证据，否则完整 staging 可直接按主Agent正文进入审读。
## 1. 配置

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" configure \
  --min-chars 3500 --target-chars 4000 --soft-max-chars 4500 \
  --writers 5 --blind-reader-count 1 --lookahead-blocks 2
```

默认**计数口径**：正文非空白字符数。标题不计；正文汉字、数字、英文、标点、括号、系统提示都计；空格、换行、Tab 不计。篇幅数字以当前用户要求为准：用户一旦给出区间/下限/上限/目标，先 `configure` 同步并只把这套数字传给 Writer；内置篇幅 fallback 只在完全没有用户篇幅要求时生效；有用户要求时不要把任何 fallback 数字带进 Writer context 或任务卡。

## 2. 准备 Wavefront

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" prepare-production --chapters 20
```

`writer_pool_size` 是最大并发容量；`speculative_lookahead_blocks` 是正常领先距离。默认约 2 个五章块，极限速度才使用 `--allow-deep-speculation`。

每个 assignment 仍是一个连续五章 ownership，保留：

```json
"write_phases": [
  {"start_chapter": 1, "end_chapter": 2, "completion_marker": ".../phase-0001-0002.complete"},
  {"start_chapter": 3, "end_chapter": 4, "completion_marker": ".../phase-0003-0004.complete"},
  {"start_chapter": 5, "end_chapter": 5, "completion_marker": ".../phase-0005-0005.complete"}
]
```

主Agent按 2+2+1 调度同一个 Writer **席位定义**，但 phase 之间必须启动新的 subagent invocation。不要 `SendMessage` / resume 上一 phase 的 agent 实例；新实例读取本席已落盘 raw 的实际结尾再续写。每个 phase 的所有 raw 确认完整后，Writer 才把对应 completion marker 写成 `complete`；partial/blocked 时不写。marker 是生产完成信号，不是字数门槛。

## 3. Writer 直接写本地 raw

Flash Writer 拥有真实：

```text
Read / Glob / Grep / Write / Edit
```

它可以直接创建 assignment 中的 raw Markdown 与 report JSON。优先读取 `context --role writer` 生成的 clean context；若缺关键稳定事实/声音，可补读 `project.md`、`canon/facts.md`、`canon/prose-contract.md`、`plot/current-arc.md`、已提交正文和本席前一章 raw。

不要再把完整 canon 手工复制进超长任务卡。

每个 phase 的每章第一次成稿就瞄准**用户 target**；不要把 fallback target 混入 Writer 任务。phase 完成后主Agent统一跑一次 `chapter-stats`；用户明确下限/上限之外才考虑最多一次长度修正，用户上限超出由 `prepare-review` 额外返回 advisory `length_warnings`。

## 4. schema3 report

Writer report 只需要：

```json
{
  "schema": 3,
  "writer": "novel-fast-writer-1",
  "start_chapter": 1,
  "end_chapter": 5,
  "chapter_notes": [
    {"chapter": 1, "summary": "", "continuity_risks": []}
  ],
  "block_interface": {
    "assumed_entry": {},
    "exit_state": {},
    "must_carry_forward": [],
    "hard_inventions": [],
    "plan_deviations": [],
    "creative_keep": [],
    "continuity_risks": []
  }
}
```

不让 Writer 填 reader_model_updates、实体 ID、current_patch、adjudications。schema1/2 数据仍可读取。

## 5. production-status：正文优先

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" production-status
```

每块输出：

- `prose_ready`：五章 raw 存在、章号正确，三个 phase completion marker 都有效，并满足用户明确配置的 hard minimum（若有）；内置 fallback 只作软提示；
- `metadata_ready`：report 也合法；
- `ready` = `prose_ready`。

completion marker 与文学长度分离：短章可以合法完成，未完成的 raw 即使文件存在也不会被视为 ready。report JSON 漏字段/损坏不会阻止主Agent整合已经通过完成信号确认的正文。标题解析同时接受：

```text
# 第1章 标题
第1章 标题
```

## 6. promote-production 与 rebase

对 `prose_ready` 的五章块，按正史顺序直接做确定性提升：

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" promote-production --start N
```

它只把 validated raw **原样**写入 `.novel/staging/`，不改文、不提交 canon、不合并 Reader/状态数据。已有 staging 与 raw 不同时默认报冲突，不会静默覆盖；主Agent只需要 Edit 真正的 hotspot。raw 仍然不能直接 commit。

对 speculative 后块：

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" rebase-production --start N
```

只有实际入口状态失配才修。report 缺失/损坏时 rebase 直接给 metadata warning，以前置块终稿和后块实际正文为准，不阻塞。

schema3 不要求逐条 `accepted/rejected/deferred`。`adjudicate-interface` 只用于 schema2 数据。

## 7. adopt-interface

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" adopt-interface --start N
```

schema3 只吸收每章 summary 等轻量信息。若 report 丢失/坏掉，也会从实际 staging 建立最小 provisional state。所有章节 hash 更新完成后再统一编译 Working State，避免章节间的临时 stale 状态干扰整块收口。

Working State stale 本身也不再阻止继续写：陈旧或损坏 provisional 会被忽略，实际 staging 正文仍作为 WIP 边界。outline node、current arc、scene/active entity 或相关 entity JSON 缺失/损坏时，Writer context 只 warning 并省略该辅助块。`state/reader-model.json` 损坏时普通 context / commit 使用空模型继续并 warning；`audit` 仍严格报告。

## 8. 盲读

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" prepare-review
```

默认轻量 continuity=skip；Writer report 中的 continuity risk 只作 advisory，不自动升级 Reviewer。先完成盲读和高价值修订；最终候选仍有具体事实、知识边界或时间线风险时，再由主Agent用 `review-continuity --invoke --reason ...` 升级。也可以在明确知道需要连续性审查时直接 `--continuity-review invoke`，但 Reviewer 应放在修订后的候选稿上运行。

默认运行：

- `novel-fast-reader-flow`：真实 `Read`；
- `novel-fast-pure-reader`：真实 `Read`，每正式单元固定一次。

Hook/Character 仅按项目配置增加。Continuity Reviewer 拥有真实 `Read/Glob/Grep`，没有写权限。

## 9. final / commit

```bash
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" finalize-review
"${CLAUDE_SKILL_DIR}/scripts/novelctl-skill" commit-unit
```

final-clean 仍硬拦确定性生产垃圾；语义 warning 只提示，不再要求办裁决手续。空 feedback adjudication 也不阻塞 finalize。

`commit-unit` 内部按顺序 prepare-delta → commit，并从 finalized review 自动带入批次末章 Reader 结论。若 events 日志损坏而当前章没有新增 events / 事件依赖，正文仍提交、坏日志原样保留并汇总 warning；事件依赖章仍严格阻止。

## 10. 运行兼容

`novelctl-skill` 项目根解析：环境变量 → project marker → 当前目录向上现有 `.novel` → 当前目录。Windows/嵌入终端尽量 UTF-8 输出。

## 11. 1—4 章余数

请求余 1—4 章由主Agent顺序写，不自动叫 tail；作品没结束就留 staging，等后续自然补成正式五章。只有真实结束才使用 `final_tail`。

## 12. audit / metrics

`audit` 和 `integration-metrics` 是诊断工具，不是进入下一波写作的许可证。正文可继续时不要为了 metadata 0 warning 停工。

## 上游修订后的接口提醒

`finalize-review` 若发现冻结后的单元正文发生了修改，同时单元之后已经存在连续 staging，会返回 `downstream_warning`，提示主Agent重新检查尾章到下一章的接口和已有后续正文。该提示不写入依赖账本，不阻止继续创作或提交。
