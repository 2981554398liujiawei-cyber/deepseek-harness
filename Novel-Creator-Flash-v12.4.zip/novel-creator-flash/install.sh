#!/usr/bin/env bash
set -euo pipefail
scope="project"; project_path=""; positional_project_path=""; force="false"; migrate="false"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --scope) [[ $# -ge 2 ]] || { echo "--scope requires a value" >&2; exit 2; }; scope="$2"; shift 2 ;;
    --project-path) [[ $# -ge 2 ]] || { echo "--project-path requires a value" >&2; exit 2; }; project_path="$2"; shift 2 ;;
    --force) force="true"; shift ;;
    --migrate) migrate="true"; shift ;;
    --*) echo "Unknown argument: $1" >&2; exit 2 ;;
    *) [[ -z "$positional_project_path" ]] || { echo "Only one positional project path is allowed" >&2; exit 2; }; positional_project_path="$1"; shift ;;
  esac
done
if [[ -n "$positional_project_path" ]]; then
  [[ "$scope" == "project" ]] || { echo "A positional project path cannot be used with --scope global" >&2; exit 2; }
  [[ -z "$project_path" || "$project_path" == "$positional_project_path" ]] || { echo "Positional project path conflicts with --project-path" >&2; exit 2; }
  project_path="$positional_project_path"
fi

python_cmd=()
for candidate in python3 python; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' >/dev/null 2>&1; then python_cmd=("$candidate"); break; fi
done
if (( ${#python_cmd[@]} == 0 )) && command -v py >/dev/null 2>&1 && py -3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' >/dev/null 2>&1; then python_cmd=(py -3); fi
(( ${#python_cmd[@]} > 0 )) || { echo "Python 3.10+ is required (python3, python, or py -3)." >&2; exit 1; }

package_root="$(cd "$(dirname "$0")" && pwd)"; source_skill="$package_root/.claude/skills/novel-creator-flash"; source_agents="$package_root/.claude/agents"
agent_names=(novel-fast-writer-1.md novel-fast-writer-2.md novel-fast-writer-3.md novel-fast-writer-4.md novel-fast-writer-5.md novel-fast-writer-6.md novel-fast-writer-7.md novel-fast-writer-8.md novel-fast-writer-9.md novel-fast-writer-10.md novel-fast-reader-flow.md novel-fast-reader-character.md novel-fast-reader-hook.md novel-fast-pure-reader.md novel-fast-continuity-reviewer.md); alternate_skill_names=(novel-creator-fast-production); alternate_agent_names=(novel-style-editor.md)
[[ -d "$source_skill" ]] || { echo "Skill source not found: $source_skill" >&2; exit 1; }
for n in "${agent_names[@]}"; do [[ -f "$source_agents/$n" ]] || { echo "Agent source not found: $n" >&2; exit 1; }; done
if find "$source_skill" "$source_agents" -type l -print -quit | grep -q .; then echo "Package source contains a symbolic link; refusing installation." >&2; exit 1; fi

if [[ "$scope" == "global" ]]; then
  claude_root="${HOME}/.claude"
elif [[ "$scope" == "project" ]]; then
  [[ -n "$project_path" ]] || project_path="$(pwd)"
  project_root="$(cd "$project_path" && pwd -P)"
  claude_root="$project_root/.claude"
else echo "scope must be project or global" >&2; exit 2; fi
skills_root="$claude_root/skills"; agents_root="$claude_root/agents"; backups_root="$claude_root/backups"
if [[ "$scope" == "project" ]]; then
  for destination in "$claude_root" "$skills_root" "$agents_root" "$backups_root"; do
    if [[ -L "$destination" ]]; then
      echo "Project installation target is a symbolic link; refusing installation: $destination" >&2
      exit 1
    fi
  done
fi
mkdir -p "$skills_root" "$agents_root" "$backups_root"
if [[ "$scope" == "project" ]]; then
  for destination in "$claude_root" "$skills_root" "$agents_root" "$backups_root"; do
    if [[ -L "$destination" ]]; then
      echo "Project installation target became a symbolic link; refusing installation: $destination" >&2
      exit 1
    fi
  done
  "${python_cmd[@]}" - "$project_root" "$claude_root" "$skills_root" "$agents_root" "$backups_root" <<'PYSAFE'
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve(strict=True)
for raw in sys.argv[2:]:
    target=Path(raw).resolve(strict=True)
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise SystemExit(f"Project installation target escapes resolved project root: {target}") from exc
PYSAFE
fi
target_skill="$skills_root/novel-creator-flash"; stamp="$(date -u +%Y%m%dT%H%M%SZ)"; token="$stamp-$$"
staging_skill="$skills_root/.novel-creator-flash.install-$token"; staging_agents="$agents_root/.novel-creator-flash-agents-install-$token"; backup_root="$backups_root/novel-creator-flash-$token"

alternate_found=()
for n in "${alternate_skill_names[@]}"; do [[ -e "$skills_root/$n" ]] && alternate_found+=("skill:$n"); done
for n in "${alternate_agent_names[@]}"; do [[ -e "$agents_root/$n" ]] && alternate_found+=("agent:$n"); done
if (( ${#alternate_found[@]} > 0 )) && [[ "$migrate" != "true" ]]; then
  printf 'Other Novel Creator component names detected (left untouched). Re-run with --migrate to back them up and remove them from active discovery:
' >&2
  printf '  %s
' "${alternate_found[@]}" >&2
fi

installed_skill="false"; installed_agents=(); migrated_skills=(); migrated_agents=()
cleanup_staging() { rm -rf "$staging_skill" "$staging_agents" 2>/dev/null || true; }
rollback_install() {
  rc=$?
  if (( rc != 0 )); then
    if [[ "$installed_skill" == "true" && -e "$target_skill" ]]; then rm -rf "$target_skill"; fi
    for n in "${installed_agents[@]:-}"; do [[ -n "$n" && -e "$agents_root/$n" ]] && rm -f "$agents_root/$n"; done
    if [[ -e "$backup_root/skill" ]]; then mv "$backup_root/skill" "$target_skill" || true; fi
    if [[ -d "$backup_root/agents" ]]; then
      for backup in "$backup_root/agents"/*; do [[ -e "$backup" ]] || continue; mv "$backup" "$agents_root/$(basename "$backup")" || true; done
    fi
    for n in "${migrated_skills[@]:-}"; do [[ -e "$backup_root/alternate-skills/$n" ]] && mv "$backup_root/alternate-skills/$n" "$skills_root/$n" || true; done
    for n in "${migrated_agents[@]:-}"; do [[ -e "$backup_root/alternate-agents/$n" ]] && mv "$backup_root/alternate-agents/$n" "$agents_root/$n" || true; done
    echo "Installation failed; previous Novel Creator components were restored where backups existed." >&2
  fi
  cleanup_staging
  return "$rc"
}
trap rollback_install EXIT
cp -RP "$source_skill" "$staging_skill"; mkdir -p "$staging_agents"; for n in "${agent_names[@]}"; do cp -P "$source_agents/$n" "$staging_agents/$n"; done
find "$staging_skill" -type d -name '__pycache__' -prune -exec rm -rf {} + 2>/dev/null || true; find "$staging_skill" -type f \( -name '*.pyc' -o -name '*.pyo' \) -delete
"${python_cmd[@]}" -m compileall -q "$staging_skill/scripts"
find "$staging_skill" -type d -name '__pycache__' -prune -exec rm -rf {} + 2>/dev/null || true; find "$staging_skill" -type f \( -name '*.pyc' -o -name '*.pyo' \) -delete

conflicts=(); [[ -e "$target_skill" ]] && conflicts+=("$target_skill"); for n in "${agent_names[@]}"; do [[ -e "$agents_root/$n" ]] && conflicts+=("$agents_root/$n"); done
if (( ${#conflicts[@]} > 0 )) && [[ "$force" != "true" ]]; then printf 'Target exists; use --force to replace with backup:
' >&2; printf '  %s
' "${conflicts[@]}" >&2; exit 1; fi
mkdir -p "$backup_root/agents" "$backup_root/alternate-skills" "$backup_root/alternate-agents"
if [[ -e "$target_skill" ]]; then mv "$target_skill" "$backup_root/skill"; fi
for n in "${agent_names[@]}"; do [[ -e "$agents_root/$n" ]] && mv "$agents_root/$n" "$backup_root/agents/$n"; done
mv "$staging_skill" "$target_skill"; installed_skill="true"
if [[ "$scope" == "project" ]]; then printf '%s\n' "$(cd "$project_path" && pwd -P)" > "$target_skill/.project-root"; fi
for n in "${agent_names[@]}"; do mv "$staging_agents/$n" "$agents_root/$n"; installed_agents+=("$n"); done; rmdir "$staging_agents"

if [[ "$migrate" == "true" ]]; then
  for n in "${alternate_skill_names[@]}"; do if [[ -e "$skills_root/$n" ]]; then mv "$skills_root/$n" "$backup_root/alternate-skills/$n"; migrated_skills+=("$n"); fi; done
  for n in "${alternate_agent_names[@]}"; do if [[ -e "$agents_root/$n" ]]; then mv "$agents_root/$n" "$backup_root/alternate-agents/$n"; migrated_agents+=("$n"); fi; done
fi
trap - EXIT
cleanup_staging
printf 'Installed novel-creator-flash Skill to %s
' "$target_skill"; printf 'Installed %s subagents to %s
' "${#agent_names[@]}" "$agents_root"
[[ "$migrate" == "true" && ${#alternate_found[@]} -gt 0 ]] && printf 'Other components moved to backup: %s
' "$backup_root"
printf 'Python launcher validated with: %s
' "${python_cmd[*]}"; printf 'Restart Claude Code so project/user subagents are reloaded.
'
