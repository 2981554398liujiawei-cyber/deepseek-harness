# Novel Creator Flash

## 运行兼容性

- Python 3.10+。
- Claude Code 2.1.228+。
- 发布验证应在真实 Claude Code 环境运行 `tests/smoke_claude_skill_permissions.py`；静态测试和 Python 测试不能替代真实 Agent / permission smoke。

## Flash 最小路径

```text
prepare-production
→ Writer A/B... 各自 2+2+1；每段新 invocation，直接写 raw
→ production-status
→ promote-production：validated raw 原样进入 staging
→ 主Agent只修 hotspot；必要时 rebase / adopt-interface
→ 冻结五章盲包，后台 Flow + Pure；仍需继续写时可继续安全 Wavefront
→ 高价值修订后，仍有具体事实风险才 Continuity
→ finalize-review
→ commit-unit
```

默认 Wavefront 仍领先约2个五章块。10个 Writer 是容量，不代表应一次猜完50章。

## 默认 Writer report schema 3

```json
{
  "schema": 3,
  "writer": "novel-fast-writer-1",
  "start_chapter": 1,
  "end_chapter": 5,
  "chapter_notes": [],
  "block_interface": {
    "assumed_entry": {},
    "exit_state": {},
    "must_carry_forward": [],
    "hard_inventions": [],
    "plan_deviations": [],
    "creative_keep": [],
    "continuity_risks": []
  }
}
```

schema1/2 数据仍可读取。

## 安装

macOS / Linux：

```bash
bash install.sh /path/to/project
```

PowerShell：

```powershell
./install.ps1 C:\path\to\project
```

## 测试

```bash
python3 tests/run_fast.py
python3 tests/run_full.py
```

真实并发吞吐仍应在实际 Claude Code 环境中验证。

## 盲读提醒

自定义 Subagent 可能加载项目/用户 `CLAUDE.md` / `CLAUDE.local.md`。不要把幕后答案、人物秘密或预期转折写入这些文件。
